# 🛡️ WPHunter BR v1.0

**Scanner Automatizado de Vulnerabilidades WordPress**  focado no público brasileiro.
Encontra falhas críticas em qualquer instalação WordPress em **menos de 60 segundos**,
com interface colorida em português e relatórios completos em HTML, JSON e CSV.

> ⚠️ **USO LEGAL OBRIGATÓRIO**
> Use **apenas** em sites próprios ou com **autorização expressa e por escrito**.
> O acesso não autorizado é crime no Brasil:
> - Lei nº **12.737/2012** (Lei Carolina Dieckmann)
> - **LGPD** nº 13.709/2018
> - Marco Civil da Internet nº **12.965/2014**

---
f
## 📦 Instalação

```bash
git clone https://github.com/Kalyel473/wphunte.git
cd wphunter
pip install -r requirements.txt
```

Compatível com **Windows** e **Linux (Kali)**. Python **3.8+**.

---

## 🚀 Uso

```bash
# Scan completo (recomendado)
python wphunter.py --url https://site.com

# Módulos isolados
python wphunter.py --url https://site.com --plugins
python wphunter.py --url https://site.com --users
python wphunter.py --url https://site.com --endpoints

# Gerar/forçar relatório HTML+JSON+CSV
python wphunter.py --url https://site.com --report

# Modo stealth (mais lento, menos ruído) / agressivo (mais rápido)
python wphunter.py --url https://site.com --stealth
python wphunter.py --url https://site.com --aggressive

# Salvar saída do terminal em arquivo
python wphunter.py --url https://site.com --output resultado.txt

# Modo não-interativo (CI/demo) — confirma autorização automaticamente
python wphunter.py --url https://site.com --yes

# Ajuda
python wphunter.py --help
```

---

## 🧩 Os 10 Módulos

| # | Módulo | O que faz |
|---|--------|-----------|
| 1 | **Detector WordPress** | Confirma WP, extrai versão, PHP, servidor, CDN, SSL e WHOIS |
| 2 | **Enumeração de Usuários** | REST API, author archive, oEmbed e sitemap |
| 3 | **Scanner de Plugins** | Detecção passiva + ativa, correlação com CVEs e CVSS |
| 4 | **Scanner de Temas** | Tema ativo/versão/autor + CVEs conhecidos |
| 5 | **Verificação de Endpoints** | xmlrpc, wp-config, listagem de diretórios, proteção de login |
| 6 | **Teste de Credenciais** | Combinações padrão + wordlist BR (modo seguro contra lockout) |
| 7 | **Scanner de Injeções** | SQLi, XSS refletido, LFI e Open Redirect (não destrutivo) |
| 8 | **Verificação SSL/Headers** | TLS, certificado e cabeçalhos de segurança |
| 9 | **Detector de Backups** | Backups, `.env`, `.git`, dumps SQL e arquivos sensíveis |
| 10 | **Gerador de Relatório** | HTML dark theme + JSON + CSV |

---

## 📄 Arquivos Gerados

- `wphunter_relatorio.html` — relatório visual dark theme com score animado
- `wphunter_resultado.json` — resultado estruturado completo
- `wphunter_vulnerabilidades.csv` — planilha de vulnerabilidades
- `wphunter_AAAAMMDD_HHMMSS.log` — log técnico de execução

---

## 🛡️ Recursos de Segurança da Ferramenta

- Confirmação **obrigatória** de autorização antes de iniciar
- Modo de teste de credenciais **conservador** (evita lockout)
- Testes de injeção **não destrutivos**
- `Ctrl+C` tratado graciosamente (salva resultados parciais)
- Timeout por módulo — nunca trava
- Retry automático, headers aleatórios e sessão reutilizada

---

## ⚖️ Disclaimer

Esta ferramenta é fornecida para **fins educacionais e de auditoria autorizada**.
Os autores não se responsabilizam por uso indevido. **Você** é o único responsável
por garantir que possui autorização legal para testar o alvo.
