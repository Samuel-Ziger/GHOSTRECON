# 🛡️ PyShield v1.0 – Antivírus Completo em Python

![Python](https://img.shields.io/badge/python-3.6+-blue.svg) ![License](https://img.shields.io/badge/license-MIT-green.svg) ![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)

**PyShield** é uma ferramenta de segurança cibernética completa escrita em Python. Realiza varreduras profundas de arquivos, processos, memória RAM, conexões de rede, programas de inicialização e integridade do sistema. Além disso, conta com limpeza de disco, quarentena de ameaças e geração de relatórios detalhados. Ideal para educação, laboratórios e uso pessoal.

---

## 📑 Índice

- [Recursos](#-recursos)
- [Instalação](#-instalação)
- [Como usar](#-como-usar)
  - [Menu interativo](#menu-interativo)
  - [Escopos de varredura](#escopos-de-varredura)
- [Módulos de análise](#-módulos-de-análise)
  - [1. Varredura de arquivos](#1-varredura-de-arquivos)
  - [2. Processos em execução](#2-processos-em-execução)
  - [3. Análise de RAM](#3-análise-de-ram)
  - [4. Conexões de rede](#4-conexões-de-rede)
  - [5. Programas de inicialização](#5-programas-de-inicialização)
  - [6. Limpeza de disco](#6-limpeza-de-disco)
  - [7. Verificação de integridade](#7-verificação-de-integridade)
  - [8. Quarentena](#8-quarentena)
- [Arquivos gerados](#-arquivos-gerados)
- [Personalização](#-personalização)
- [Avisos e limitações](#-avisos-e-limitações)
- [Contribuição](#-contribuição)
- [Licença](#-licença)

---

## 🌟 Recursos

- 🔍 **Análise heurística** de arquivos baseada em:
  - Assinaturas binárias (EICAR e outros padrões)
  - Hashes MD5 conhecidos
  - Nomes suspeitos (regex)
  - Extensões duplas (engenharia social)
  - Conteúdo de scripts (PowerShell, Python, Bash, etc.)
  - Permissões perigosas (SUID/SGID no Linux)
- 🧠 **Monitor de processos** com detecção de nomes maliciosos, consumo anormal de CPU e execução a partir de pastas temporárias.
- 📊 **Análise de RAM** com exibição dos 5 maiores consumidores.
- 🌐 **Varredura de rede** identificando portas suspeitas e conexões para IPs externos.
- 🚀 **Verificação de inicialização** (Registro no Windows, `autostart` no Linux, LaunchAgents no macOS).
- 🧹 **Limpeza de disco** automática de arquivos temporários, caches e logs antigos.
- 🛡️ **Quarentena** que move arquivos suspeitos para uma pasta isolada.
- 📝 **Relatório detalhado** em JSON e log de execução.
- 🎨 Interface colorida e progresso animado.

---

## 📦 Instalação

### Pré‑requisitos
- Python 3.6 ou superior
- `pip` instalado

### Dependências
O próprio script instala automaticamente os pacotes necessários na primeira execução:
- [`psutil`](https://pypi.org/project/psutil/) – informações do sistema e processos
- [`colorama`](https://pypi.org/project/colorama/) – cores no terminal

### Clonar e executar

```bash
git clone https://github.com/kalyel473/pyshield.git
cd Antivirus
python Clean.py
