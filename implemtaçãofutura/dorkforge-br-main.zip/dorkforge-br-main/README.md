# 🔱 DorkForge BR

> Ferramenta CLI de **Google Hacking / Google Dorking** para **OSINT e reconhecimento autorizado**, com módulo dedicado ao **contexto brasileiro** (`.gov.br`, `.edu.br`, `.com.br`, CPF/CNPJ, portais de transparência).

DorkForge BR ajuda pesquisadores de segurança, pentesters, *bug bounty hunters* e estudantes a **construir, organizar e lançar** consultas avançadas do Google de forma rápida, organizada e — acima de tudo — **ética e dentro dos Termos de Serviço**.

---

## ⚖️ AVISO LEGAL

> **Esta ferramenta destina-se *exclusivamente* a fins *educacionais*, pesquisa de segurança, testes de invasão *autorizados* e programas de *bug bounty*.**
>
> O uso de Google Dorking para acessar, coletar ou expor dados de terceiros **sem autorização** pode violar a **Lei nº 12.737/2012 (Lei Carolina Dieckmann)** e a **LGPD — Lei nº 13.709/2018**.
>
> **O usuário é o único responsável pelo uso desta ferramenta.** Use apenas em alvos que você possui ou tem permissão expressa para testar.

A ferramenta **não** baixa, armazena ou exibe conteúdo de terceiros automaticamente — ela apenas **constrói consultas e as abre no seu navegador**.

---

## 🧭 Filosofia / Arquitetura ética

DorkForge BR **não faz scraping dos resultados do Google.** Fazer isso viola os Termos de Serviço do Google e resulta em bloqueios/CAPTCHA. Em vez disso, a ferramenta funciona como um **gerador e lançador de dorks**:

1. **Constrói** a query com os operadores corretos.
2. **Gera** a URL de busca pronta.
3. **Abre** a busca no seu **navegador padrão** (`webbrowser` da stdlib).
4. **Exporta** as queries e URLs para uso manual.

> 💡 Para coleta automatizada de resultados, o caminho correto e legal é a **[Google Custom Search JSON API](https://developers.google.com/custom-search/v1/overview)** (que exige chave de API). Isso está **fora do escopo** desta ferramenta por decisão de projeto.

---

## ✨ Funcionalidades

- 🗂️ **Banco de dorks pré-definidos**, em 10 categorias temáticas + 8 categorias do módulo BR (18 no total).
- 🇧🇷 **Módulo brasileiro** (`data/dorks_br.json`): CPF/CNPJ, `.gov.br`, `.edu.br`, transparência.
- 🛠️ **Construtor fluente** (`DorkBuilder`) com 16+ operadores do Google.
- 🌐 **Gerador de URLs** para **Google**, **Bing** e **DuckDuckGo**.
- 🚀 **Lançador no navegador** com *rate limiting* configurável.
- 🎨 **CLI interativa colorida** (banner ASCII + menu numerado).
- ⌨️ **Modo automação via `argparse`**.
- 📤 **Exportação** em **TXT, JSON, CSV e HTML** (relatório dark mode com links clicáveis).
- 💾 **Carregar listas customizadas** de dorks (JSON).
- 📊 **Estatísticas** de sessão e **logging** em arquivo.

---

## 📦 Instalação

Requer **Python 3.8+**. A única dependência externa é o `colorama` (cores no terminal); se não estiver instalado, a ferramenta funciona mesmo assim, sem cores.

```bash
# 1. Clone o repositório
git clone https://github.com/kalyel473/dorkforge-br.git
cd dorkforge-br

# 2. (opcional) crie um ambiente virtual
python -m venv .venv
# Windows:  .venv\Scripts\activate
# Linux:    source .venv/bin/activate

# 3. Instale a dependência
pip install -r requirements.txt
```

> Funciona em **Windows (PowerShell)**, **Linux** e **Termux/Android**.

---

## 🚀 Uso

### Modo interativo (menu)

```bash
python dorkforge.py
```

```
[1]  Listar categorias de dorks
[2]  Gerar dorks de uma categoria
[3]  Construir dork customizado
[4]  Definir alvo (site/domínio)
[5]  Abrir dorks no navegador
[6]  Exportar resultados (TXT/JSON/CSV/HTML)
[7]  Carregar lista customizada (JSON)
[8]  Configurações (delay, motor de busca)
[9]  Buscar dorks por palavra-chave
[10] Ver / limpar seleção atual
[0]  Sair
```

### Modo linha de comando (automação)

```bash
# Listar todas as categorias
python dorkforge.py --listar --aceito-termos

# Gerar dorks de uma categoria, aplicar alvo e abrir no navegador (delay 3s)
python dorkforge.py --categoria arquivos --alvo exemplo.com.br --abrir --delay 3 --aceito-termos

# Construir um dork customizado e exportar em HTML
python dorkforge.py --custom --site "*.gov.br" --filetype xls --intext "CPF" --export html --aceito-termos

# Buscar por palavra-chave e exportar em vários formatos
python dorkforge.py --buscar senha --export txt json csv html --aceito-termos

# Usar outro motor de busca
python dorkforge.py --custom --inurl admin --motor duckduckgo --abrir --aceito-termos
```

> Na primeira execução interativa, é preciso **aceitar o aviso legal** uma vez (fica salvo em `config.json`). No modo CLI, use `--aceito-termos`.

---

## 🧱 Operadores suportados (`DorkBuilder`)

| Operador | Método | Exemplo gerado |
|---|---|---|
| `site:` | `.site("*.gov.br")` | `site:*.gov.br` |
| `inurl:` | `.inurl("admin")` | `inurl:admin` |
| `allinurl:` | `.allinurl("admin", "login")` | `allinurl:admin login` |
| `intitle:` | `.intitle("index of")` | `intitle:"index of"` |
| `allintitle:` | `.allintitle("painel", "admin")` | `allintitle:painel admin` |
| `intext:` | `.intext("CPF")` | `intext:"CPF"` |
| `allintext:` | `.allintext("usuario", "senha")` | `allintext:usuario senha` |
| `filetype:` | `.filetype("pdf")` | `filetype:pdf` |
| `ext:` | `.ext("bak")` | `ext:bak` |
| `cache:` | `.cache("exemplo.com.br")` | `cache:exemplo.com.br` |
| `related:` | `.related("exemplo.com.br")` | `related:exemplo.com.br` |
| `before:`/`after:` | `.after("2024-01-01")` | `after:2024-01-01` |
| `AROUND(n)` | `.around("senha", 3, "admin")` | `senha AROUND(3) admin` |
| `"..."` | `.exact("acesso restrito")` | `"acesso restrito"` |
| `OR` | `.any_of("pdf", "doc")` | `(pdf OR doc)` |
| `-` | `.exclude("www")` | `-www` |
| `( )` | `.group(...)` | `(intext:cpf OR intext:cnpj)` |
| livre | `.raw("site:*.gov.br")` | (texto bruto) |

### Exemplo programático

```python
from core.operators import DorkBuilder

dork = (DorkBuilder()
        .site("*.gov.br")
        .filetype("xls")
        .intext("CPF")
        .build())
print(dork)                 # site:*.gov.br filetype:xls intext:"CPF"
print(DorkBuilder().site("*.gov.br").to_url("google"))
```

---

## 📂 Estrutura do projeto

```
.
├── dorkforge.py            # Ponto de entrada + CLI (menu + argparse)
├── core/
│   ├── __init__.py
│   ├── operators.py        # DorkBuilder (operadores + fluent interface)
│   ├── database.py         # Banco de dorks pré-definidos por categoria
│   ├── launcher.py         # Geração de URL + abertura no navegador
│   └── exporter.py         # Exportação TXT/JSON/CSV/HTML
├── data/
│   └── dorks_br.json       # Dorks brasileiros
├── output/                 # Relatórios exportados (criado em runtime)
├── requirements.txt        # apenas: colorama
└── README.md
```

Arquivos gerados em runtime: `config.json` (preferências) e `dorkforge.log` (operações).

---

## 📤 Formatos de exportação

| Formato | Conteúdo |
|---|---|
| **TXT** | Lista simples de dorks + URLs, agrupada por categoria. |
| **JSON** | Estruturado: categoria, título, dork, url, timestamp e disclaimer. |
| **CSV** | Colunas `categoria, titulo, dork, url` (abre no Excel/LibreOffice). |
| **HTML** | Relatório responsivo *dark mode*, tabelas por categoria, **links clicáveis** e rodapé legal. |

Todos salvos em `output/` com timestamp no nome (`dorkforge_AAAAMMDD_HHMMSS.ext`).

---

## 🗃️ Adicionando seus próprios dorks

Crie um JSON no mesmo formato de `data/dorks_br.json` e carregue pela opção **[7]** do menu (ou edite o próprio arquivo BR):

```json
{
  "categorias": [
    {
      "nome": "Minha categoria",
      "descricao": "Descrição da categoria.",
      "dorks": [
        { "titulo": "Meu dork", "dork": "site:*.br intext:\"exemplo\"", "descricao": "..." }
      ]
    }
  ]
}
```

---

## 🤝 Contribuindo

Sugestões de novos dorks (legais e úteis), melhorias de UX e correções são bem-vindas via *issues* e *pull requests*. Mantenha o foco **defensivo/educacional** e o respeito aos ToS.

## 📄 Licença

Distribua sob a licença de sua preferência (ex.: MIT). Lembre-se: a responsabilidade pelo uso é sempre do usuário final.

---

<p align="center"><i>Feito para a comunidade brasileira de segurança. Use com responsabilidade. 🇧🇷🔒</i></p>
