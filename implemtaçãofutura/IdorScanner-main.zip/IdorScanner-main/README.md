# 🛡️ IDOR Lab Scanner

**Ferramenta educacional para demonstrar — visualmente e em tempo real — como funciona a vulnerabilidade IDOR (*Insecure Direct Object Reference*).**

## ⚠️ Aviso legal (leia antes de usar)

Esta ferramenta é **material educacional** para ser usada **exclusivamente** contra alvos que **você controla** (localhost, redes privadas) **ou** alvos para os quais você tem **autorização explícita e por escrito** (ex.: contrato de pentest).

Usar ferramentas de teste de intrusão contra sistemas de terceiros **sem autorização é CRIME** no Brasil — **Lei nº 12.737/2012 (Lei Carolina Dieckmann)**, que inseriu o art. 154-A no Código Penal (invasão de dispositivo informático).

**Travas de segurança embutidas no scanner:**

- Por padrão, **só aceita alvos** em `127.0.0.1` (localhost) ou faixas privadas (`10.x`, `172.16–31.x`, `192.168.x`).
- Para apontar a um alvo **público**, é **obrigatório** passar a flag `--i-have-authorization` (e a responsabilidade legal passa a ser inteiramente sua).
- Exibe um **banner de aviso legal** sempre que inicia.

Todos os dados exibidos (nomes, CPFs, saldos) são **fictícios** e gerados localmente.

---

## 📦 O que vem no projeto

| Arquivo | Descrição |
|---|---|
| `target_app.py` | App web Flask **propositalmente vulnerável** a IDOR (o alvo de laboratório). |
| `idor_scanner.py` | A ferramenta: explora o IDOR com TUI visual, relatórios e módulo educacional. |
| `requirements.txt` | Dependências (`flask`, `requests`, `rich`). |
| `README.md` | Este arquivo. |

---

## 🚀 Instalação

Requer **Python 3.10+** (testado também no 3.14). Funciona em **Windows (PowerShell)** e **Linux (Kali)**.

```bash
# 1) (Opcional, recomendado) crie e ative um ambiente virtual
python -m venv .venv

# Windows (PowerShell):
.venv\Scripts\Activate.ps1
# Linux/Kali:
source .venv/bin/activate

# 2) Instale as dependências
pip install -r requirements.txt
```

---

## 🧪 Como rodar o laboratório

Você precisa de **dois terminais**: um para o alvo, outro para o scanner.

### Terminal 1 — sobe o alvo vulnerável

```bash
python target_app.py
```

Saída esperada:

```
======================================================================
  IDOR LAB  —  APP-ALVO VULNERÁVEL (uso EXCLUSIVO em laboratório)
======================================================================
  Servindo em   : http://127.0.0.1:5000
  Usuários fake : 50
  Endpoint VULN : GET /api/usuario/<id>
  Endpoint OK   : GET /api/usuario-seguro/<id>
```

### Terminal 2 — roda o scanner contra o alvo

```bash
python idor_scanner.py --url http://127.0.0.1:5000/api/usuario/ --inicio 1 --fim 50 --meu-id 1
```

O scanner vai varrer os IDs de 1 a 50 e, como o endpoint é vulnerável, vai **vazar os dados de todos os 50 usuários** — exibindo tudo numa tabela ao vivo, com as linhas vulneráveis em vermelho.

---



## 🧰 Referência das flags do scanner

| Flag | Descrição |
|---|---|
| `--url` | URL base do endpoint. Aceita `{id}` como placeholder; senão, o ID é anexado ao final. |
| `--inicio` / `--fim` | Range de IDs a testar (padrão: 1 a 50). |
| `--meu-id` | ID do usuário autenticado. Acessar **outro** ID é contado como vazamento. |
| `--token` | Token de sessão (ex.: `token-1`). Enviado como `Authorization: Bearer`. |
| `--cookie` | Cookie de sessão bruto (ex.: `sessao=token-1`). |
| `--timeout` | Timeout por requisição, em segundos (padrão: 5). |
| `--dramatic` | Modo cinematográfico: adiciona delays para a gravação. |
| `--delay` | Delay (s) entre requisições no modo `--dramatic` (padrão: 0.12). |
| `--export` | Salva relatórios em **JSON** e **HTML**. |
| `--saida` | Prefixo dos arquivos de saída (padrão: `relatorio_idor`). |
| `--explicar` | Mostra o módulo educacional sobre IDOR e encerra. |
| `--i-have-authorization` | Permite alvos públicos (só com autorização explícita). |

---

## 🔍 Como o scanner detecta o vazamento

Para cada ID testado, ele faz um **diff inteligente** da resposta e marca como **vazamento** quando:

1. o status é **200**, **e**
2. o corpo é um JSON com pelo menos um **campo sensível** (`cpf`, `saldo_conta`, `senha_hash`), **e**
3. o registro **não é** o do próprio usuário autenticado (`--meu-id`).

Quando você aponta para `/api/usuario-seguro/`, o servidor responde **401/403** para IDs de terceiros → o critério não é satisfeito → **nenhum vazamento** é reportado.

---

## 🧠 Endpoints do alvo (`target_app.py`)

| Método | Rota | Comportamento |
|---|---|---|
| `GET` | `/` | Página de status com instruções. |
| `POST` | `/api/login` | Body `{"id": 1}` → devolve `token-1`. Login simplificado de lab. |
| `GET` | `/api/usuario/<id>` | **❌ Vulnerável (IDOR)** — devolve qualquer usuário sem checar permissão. |
| `GET` | `/api/usuario-seguro/<id>` | **✅ Corrigido** — valida o token e só devolve o próprio usuário (senão 401/403). |

---

## ❓ Resolução de problemas

- **`Conexão recusada`** no scanner → o `target_app.py` não está rodando. Suba ele primeiro (Terminal 1).
- **`ModuleNotFoundError`** → faltou `pip install -r requirements.txt` (ou o venv não está ativo).
- **A porta 5000 está ocupada** → finalize o processo que a usa ou altere `PORT` no topo de `target_app.py`.
- **Cores estranhas no terminal Windows** → use o **Windows Terminal** (suporta cores ANSI melhor que o `cmd` antigo).

---

## 📚 Licença / uso

Projeto **educacional**, sem garantias. Use por sua conta e risco, **somente** em laboratório próprio ou com autorização explícita. O autor não se responsabiliza por uso indevido.
